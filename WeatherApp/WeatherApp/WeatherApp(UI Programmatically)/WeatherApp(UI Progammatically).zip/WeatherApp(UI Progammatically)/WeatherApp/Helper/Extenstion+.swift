//
//  Extenstion+.swift
//  WeatherApp
//
//  Created by MRGS on 24.08.2022.
//

import UIKit
//MARK: - Image enum
enum weatherIcon:String{
    case sun = "Sun"
    case Cloud = "Cloud" 
}
enum navIcon:String{
    case backButton = "chevron.backward"
}
extension UIColor{
    
    final class Label{
        static let labelPrimary = UIColor(named: "Label.Primary")
        static let labelSecondary = UIColor(named: "Label.Secondary")
        static let labelTertiary = UIColor(named: "Label.Tertiary")
    }
    final class TextField{
        // Label.Secondary = TextField.Label.Placeholder
        static let label = UIColor(named: "TextField.Label.Placeholder")
        static let placeholder = UIColor(named: "TextField.Label.Placeholder")
        static let background = UIColor(named: "TextField.Background")
    }
    final class Support{
        static let background = UIColor(named: "Main.Background")
        static let border = UIColor(named: "Main.Border")
    }
}
//MARK: - UIFont extension
extension UIFont{
    static let poppinsMedium = "Poppins-Medium"
    static let poppinsRegular = "Poppins-Regular"
    static let poppinsSemiBold = "Poppins-SemiBold"
    static let poppinsBold = "Poppins-Bold"
}

//MARK: - UIViewController extension
extension UIViewController{
    //    func clearBackgroundNavigationBar(){
    //        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for:.default)
    //        self.navigationController?.navigationBar.shadowImage = UIImage()
    //        self.navigationController?.navigationBar.layoutIfNeeded()
    //    }
    @objc func popVC()  {
        
        Vibration.light.vibrate()
        navigationController?.popViewController(animated: true)
    }
}
//MARK: - UIBarButtonItem extension
extension UIBarButtonItem {
    
        static func addButton(systemNameIcon:String,_ target: Any?, action: Selector) -> UIBarButtonItem {
            let button = UIButton()
            let largeFont = UIFont.systemFont(ofSize: 20)
            let configuration = UIImage.SymbolConfiguration(font: largeFont)
            button.setImage(UIImage(systemName: systemNameIcon,withConfiguration: configuration), for: .normal)
            button.tintColor =  .systemPink
            button.layer.borderWidth = 2
            button.backgroundColor = .white
            button.layer.cornerRadius = 12
            button.addTarget(target, action: action, for: .touchUpInside)
    
            let menuBarItem = UIBarButtonItem(customView: button)
            menuBarItem.customView?.translatesAutoresizingMaskIntoConstraints = false
            menuBarItem.customView?.heightAnchor.constraint(equalToConstant: 41).isActive = true
            menuBarItem.customView?.widthAnchor.constraint(equalToConstant: 41).isActive = true
    
            return menuBarItem
        }
}
enum Vibration {
    case error
    case success
    case warning
    case light
    case medium
    case heavy
    @available(iOS 13.0, *)
    case soft
    @available(iOS 13.0, *)
    case rigid
    case selection
    
    public func vibrate() {
        switch self {
        case .error: // легкая double вибрация
            UINotificationFeedbackGenerator().notificationOccurred(.error)
        case .success: // легкая вибрация
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        case .warning: // легкая с задержкой
            UINotificationFeedbackGenerator().notificationOccurred(.warning)
        case .light: //легкая один раз
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
        case .medium:
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        case .heavy:
            UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
        case .soft:
            if #available(iOS 13.0, *) {
                UIImpactFeedbackGenerator(style: .soft).impactOccurred()
            }
        case .rigid:
            if #available(iOS 13.0, *) {
                UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
            }
        case .selection:
            UISelectionFeedbackGenerator().selectionChanged()
        }
    }
    
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tapGesture = UITapGestureRecognizer(target: self,
                                                action: #selector(hideKeyboard))
        view.addGestureRecognizer(tapGesture)
    }
    
    @objc func hideKeyboard() {
        view.endEditing(true)
    }
    func customFontNavBar()  {
        self.navigationController!.navigationBar.titleTextAttributes = [
            NSAttributedString.Key.font: UIFont(name: UIFont.poppinsSemiBold, size: 20)!
        ]
        self.navigationController?.navigationBar.titleTextAttributes = [
            NSAttributedString.Key.foregroundColor: UIColor.Label.labelPrimary ?? .label
        ]
    }
}

extension UIViewController {
    func presentSearchAlertController(withTitle title: String?,
                                      message: String?,
                                      style: UIAlertController.Style,
                                      completionHandler: @escaping (String) -> Void) {
        let ac = UIAlertController(title: title, message: message, preferredStyle: style)
        ac.addTextField { tf in
            let cities = ["San Francisco", "Moscow", "New York", "Stambul", "Viena"]
            tf.placeholder = cities.randomElement()
        }
        let search = UIAlertAction(title: "Search", style: .default) { action in
            let textField = ac.textFields?.first
            guard let cityName = textField?.text else { return }
            if cityName != "" {
                print("search info for the \(cityName)")
//                self.networkWeatherManager.fetchCurrentWeather(forCity: cityName)
                let city = cityName.split(separator: " ").joined(separator: "%20")
                completionHandler(city)
            }
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        ac.addAction(search)
        ac.addAction(cancel)
        present(ac, animated: true, completion: nil)
    }
}
