//
//  CurrentWeather.swift
//  WeatherApp
//
//  Created by MRGS on 25.08.2022.
//

import Foundation
struct CurrentWeather {
    var cityName:String
    
    let temperature:Double
    var temperatureString:String{
        return  "\(Int(temperature))"
    }
    
    
    let feelsLikeTemperature:Double
    var feelsLikeTemperatureString:String{
        return  "\(feelsLikeTemperature.rounded())"
    }
    
    let conditionCode:Int
    
    var systemIconNameString: String {
        switch conditionCode {
        case 200...232: return "Cloud"
        case 300...321: return "cloud.drizzle.fill"
        case 500...531: return "CloudLightningRain"
        case 600...622: return "CloudSnow"
        case 701...781: return "Moon"
        case 800: return "Sun"
        case 801...804: return "CloudSun"
        default: return "nosign"
        }
    }
    
    init?(currentWeatherData:CurrentWeatherData){
        cityName = currentWeatherData.name
        temperature = currentWeatherData.main.temp
        feelsLikeTemperature = currentWeatherData.main.feelsLike
        conditionCode = currentWeatherData.weather.first!.id
    }
}
