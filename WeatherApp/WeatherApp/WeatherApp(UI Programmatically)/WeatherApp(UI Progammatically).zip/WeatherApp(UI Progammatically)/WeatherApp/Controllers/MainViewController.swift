//
//  ViewController.swift
//  WeatherApp
//
//  Created by MRGS on 24.08.2022.
//

import UIKit
import CoreLocation

class MainViewController: UIViewController {
    var networkWeatherManager = NetworkWeatherManager() 
    private let background: UIImageView = {
        let backgroundImage = UIImageView(image: UIImage(named: "clearWeatherBackground"))
        backgroundImage.contentMode = .scaleToFill
        //        backgroundImage.alpha = 0.9
        backgroundImage.translatesAutoresizingMaskIntoConstraints = false
        return backgroundImage
    }()
    lazy var locationManager: CLLocationManager = {
        let locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyKilometer
        locationManager.requestWhenInUseAuthorization()
        return locationManager
    }()
    private let weatherIconImageView: UIImageView = {
        let backgroundImage = UIImageView()
        backgroundImage.contentMode = .scaleAspectFit
        backgroundImage.translatesAutoresizingMaskIntoConstraints = false
        return backgroundImage
    }()
    private let cityLabel: UILabel = {
        let label = UILabel()
        label.text = ""
        label.font =  UIFont(name: UIFont.poppinsSemiBold, size: 30)
        label.textColor = UIColor.Label.labelPrimary
        label.adjustsFontForContentSizeCategory = true
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    private let temperatureLabel: UILabel = {
        let label = UILabel()
        label.text = ""
        label.font =  UIFont(name: UIFont.poppinsMedium, size: 70)
        label.textColor = UIColor.Label.labelPrimary
        label.adjustsFontForContentSizeCategory = true
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    private let feelsLikeTemperatureLabel: UILabel = {
        let label = UILabel()
        label.font =  UIFont(name: UIFont.poppinsMedium, size: 20)
        label.textColor = UIColor.Label.labelPrimary
        label.adjustsFontForContentSizeCategory = true
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    private lazy var locationFindButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = .black
        button.setImage(UIImage(systemName: "magnifyingglass"), for: .normal)
        button.tintColor = .white
        button.titleLabel?.font =  UIFont(name: UIFont.poppinsBold, size: 15)
        button.layer.cornerRadius = 15
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(openSearchVC), for: .touchUpInside)
        return button
    }()
    @objc func openSearchVC(){
        self.presentSearchAlertController(withTitle: "Enter city name", message: nil, style: .alert) { [unowned self] cityName in
            self.networkWeatherManager.fetchCurrentWeather(forRequestType: .cityName(city: cityName))
        }
    }
    private let stackView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        //        stack.backgroundColor = .systemPink
        stack.distribution  = .fill
        stack.alignment = .fill
        //        stack.spacing = 2
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()
    private let stackViewTemp: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.distribution  = .equalSpacing
        stack.alignment = .center
        stack.spacing = 0
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        customFontNavBar()
        title = "Weather"
        maskToConstraints()
        
        networkWeatherManager.onCompletion = { [weak self] currentWeather in
            guard let self = self else { return }
            self.updateUI(weather: currentWeather)
        }
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.requestLocation()
        }
    }
    func updateUI(weather: CurrentWeather) {
        DispatchQueue.main.async {
            self.locationFindButton.setTitle(weather.cityName.uppercased(), for: .normal)
            self.cityLabel.text = weather.cityName
            self.temperatureLabel.text = weather.temperatureString
            self.feelsLikeTemperatureLabel.text = "Feels Like: \(weather.feelsLikeTemperatureString)"
            self.weatherIconImageView.image = UIImage(named: weather.systemIconNameString)
        }
    }
     
    
   
}

  
extension MainViewController{
    func maskToConstraints()  {
        // addSubviews
        view.addSubview(background)
        view.addSubview(locationFindButton)
        view.addSubview(stackView)
        stackView.addArrangedSubview(weatherIconImageView)
        stackView.addArrangedSubview(cityLabel)
        stackView.addArrangedSubview(stackViewTemp)
        stackViewTemp.addArrangedSubview(temperatureLabel)
        stackViewTemp.addArrangedSubview(feelsLikeTemperatureLabel)
        
        //Constraints
        NSLayoutConstraint.activate([
            background.topAnchor.constraint(equalTo: view.topAnchor),
            background.leftAnchor.constraint(equalTo: view.leftAnchor),
            background.rightAnchor.constraint(equalTo: view.rightAnchor),
            background.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            locationFindButton.centerXAnchor.constraint(equalTo: view.centerXAnchor,constant: 0),
            locationFindButton.bottomAnchor.constraint(equalTo: view.bottomAnchor,constant: -20),
            locationFindButton.heightAnchor.constraint(equalToConstant: 46),
            locationFindButton.widthAnchor.constraint(equalToConstant: 150),
            weatherIconImageView.heightAnchor.constraint(equalToConstant: 104),
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            stackView.leftAnchor.constraint(equalTo: view.leftAnchor),
            stackView.rightAnchor.constraint(equalTo: view.rightAnchor)
        ])
        
    }
}
extension MainViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        let latitude = location.coordinate.latitude
        let longitude = location.coordinate.longitude
        networkWeatherManager.fetchCurrentWeather(forRequestType: .coordinate(latitude: latitude, longitude: longitude))
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
    }
}
